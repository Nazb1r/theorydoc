<?php
$redirUrl = $_SERVER['REDIRECT_URL'] ?? '/';

// редирект страниц
$html = match ($redirUrl) {
  '/' => '/html/main.html',
  '/about' => '/html/about.html',
  '/services' => '/html/services.html',
  '/portfolio' => '/html/portfolio.html',
  '/contact' => '/html/contact.html',
  default => '/html/404.html',
};

// meta description
$description = match ($redirUrl) {
  '/' => 'Широкий выбор оцинкованного кровельного профлиста напрямую от производителя. Лучшие цены в Москве! Гарантия на продукцию до 50 лет.',

  '/about' => 'История компании «ЦинкЛист» началась в 1996 г.* — именно тогда открылся первый завод в Зеленограде. 2 производственные линии, 2 вида металлочерепицы, 20 человек — так зарождалась компания, которая позже станет мировым лидером** в области изделий для строительства из тонколистовой стали.',

  '/services' => 'Услуги компании «ЦинкЛист» — производство профлиста по индивидуальным размерам, оцинковку и полимерное покрытие металла, доставку, резку и монтаж профнастила. Качественные материалы, точные размеры и быстрая обработка заказов.',

  '/portfolio' => 'Портфолио компании «ЦинкЛист» — готовые проекты по монтажу заборов, кровли и фасадов из профлиста. Примеры работ: профнастил С21, Н60, индивидуальные решения для объектов в Нижнем Новгороде и Дзержинске.',

  '/contact' => 'Контакты компании «ЦинкЛист» — телефоны, адреса офисов и email для заявок и консультаций. Свяжитесь с нами для консультации, заказа или расчета стоимости.',

  default => '',
};

// meta keywords
$keywords = match ($redirUrl) {
  '/' => 'оцинкованный профлист, кровельный профлист, купить профлист, профлист от производителя, профлист Москва, профлист цена, профнастил оцинкованный, профлист для крыши, профлист для забора, металл профиль, цинковый лист, кровельные материалы, строительные материалы, лист оцинкованный, ЦинкЛист',

  '/about' => 'ЦинкЛист, история компании ЦинкЛист, производитель профлиста, завод ЦинкЛист, производство металлочерепицы, строительство из тонколистовой стали, металлические изделия, завод металлочерепицы, производитель кровельных материалов, металлочерепица ГОСТ, качество ISO 9001, профлист Россия, лидер рынка металлочерепицы, производство сэндвич-панелей, строительные материалы из металла',

  '/services' => 'услуги ЦинкЛист, производство профлиста, оцинковка металла, полимерное покрытие металла, доставка профнастила, резка металла, монтаж профнастила, изготовление профлиста под заказ, обработка металла, плазменная резка, кровельные работы, установка заборов из профлиста, фасадные системы, консультации по выбору профнастила, изготовление металлоконструкций',

  '/portfolio' => 'портфолио ЦинкЛист, проекты профлист, монтаж заборов из профнастила, кровля из профлиста, фасады из металлопрофиля, профнастил С21, профнастил Н60, работы ЦинкЛист, готовые объекты, монтаж кровли, монтаж фасадов, строительство из профнастила, Нижний Новгород, Дзержинск, примеры работ профлист',

  '/contact' => 'контакты ЦинкЛист, телефон ЦинкЛист, адрес ЦинкЛист, email ЦинкЛист, офисы продаж ЦинкЛист, связь с компанией, заказать звонок, отдел продаж ЦинкЛист, консультация по профлисту, заявка на профнастил, Москва, Лобня, Дзержинский, контактный центр ЦинкЛист',

  default => '',
};

// header навигационное меню
$menu = [
  '/' => 'Главная',
  '/about' => 'О компании',
  '/services' => 'Услуги',
  '/portfolio' => 'Портфолио',
  '/contact' => 'Контакты',
];

// заголовок title
$title = $menu[$redirUrl] ?? 'Страница не найдена';

if ($title == 'Страница не найдена')
  http_response_code(404);

?>

<!DOCTYPE html>
<html lang="ru">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?= $description ?>">
  <meta name="keywords" content="<?= $keywords ?>">
  <meta name="robots" content="all">
  <title><?= $title ?> — ЦинкЛист</title>
  <link href="/css/bootstrap.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>

<body>
  <div class="d-flex flex-column vh-100">
    <header class="border-bottom">
      <nav class="navbar header_nav navbar-expand-lg p-3">
        <div class="container-xxl">
          <a class="navbar-brand" href="/">ЦинкЛист</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Переключатель навигации">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <?php foreach ($menu as $url => $title) { ?>
                <?php $active = str_starts_with($redirUrl, $url) && $url != '/' ? 'active' : ($redirUrl === '/' && $url == '/' ? 'active' : ''); ?>
                <li class="nav-item">
                  <a class="nav-link <?= $active ?>" href="<?= $url ?>"><?= $title ?></a>
                </li>
              <?php } ?>
            </ul>
            <form class="d-flex" role="search">
              <input class="form-control me-3" type="search" placeholder="Поиск" aria-label="Поиск">
              <button class="btn btn-outline-dark" type="submit">Поиск</button>
            </form>
          </div>
        </div>
      </nav>
    </header>

    <main class="flex-grow-1">
      <?php include __DIR__ . $html ?>
    </main>

    <footer class="py-3 border-top mt-3">
      <ul class="nav justify-content-center pb-3 mb-3">
        <?php foreach ($menu as $url => $title) { ?>
          <li class="nav-item"><a href="<?= $url ?>" class="nav-link px-2 text-body-secondary"><?= $title ?></a></li>
        <?php } ?>
      </ul>
      <p class="text-center text-body-secondary">© 2025 ЦинкЛист</p>
    </footer>
  </div>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>